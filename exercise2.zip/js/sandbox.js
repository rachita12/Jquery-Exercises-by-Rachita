function QuestionParts() {
  
}
QuestionParts.prototype = {
    /*part A = Stores all the "alt" value of all the  images and displays it in an alert box*/
  selectAltValues: function (){  
    var altNum = [];
    var i = 0;
    while( i < $('img[alt]').length){
      $('img').each(function(){
      altNum[i] = $(this).attr("alt");
      i++;
      });
    }
    alert("Alt attributes' value for all the images having 'alt' are = " + altNum);
  },
    /*part B = This does to the "#search" input box then traverse up till it finds "form" and then adds a class to form
    which we check by giving the class a background color of pink.*/
  addClassToForm: function(){ 
    $("#search").parents("form").addClass("firstForm");
    $(".firstForm").css("backgroundColor","pink");
  },

    /*part C = Finds the list elements with class "current" and removes class from those elements and set class 
    of the next element as "current". To check whether the class was assigned or not, we turn the background 
    to orange.*/
  removeAndAddClass: function() {
    $('#myList li.current').removeClass("current").next().addClass("current");
    $('.current').css("backgroundColor","orange");
  },

    /*part D = We go to the selected item of the list. Then to iyts parent ehich is <select> then again to the
    result's parent i.e. to <slects>'s parent which is <p> then to its sibling "submit" button. We provide
    a border to check the traversing.*/
  traverseToSubmit: function(){
    $('#specials').find(":selected").parent().parent().siblings(":submit").css("border","3px solid black");
  },
    /*part E = Finds the first element of the list "#slideshow" and add a class "current" to its frist item and
    a class "disabled" to the next. We set the backgroundColor to check proper traversing*/
  addClassToNext: function(){
    $('#slideshow li').first().addClass("current").next().addClass("disabled");
    $('.disabled').css("backgroundColor","blue");
    $('#slideshow li.current').css("backgroundColor","orange");
  }
}

$(document).ready(function(){
  var questionParts = new QuestionParts();
  //part A
  questionParts.selectAltValues();
  //part B
  questionParts.addClassToForm();
  //part C
  questionParts.removeAndAddClass();
  //part D
  questionParts.traverseToSubmit();
  //part E
  questionParts.addClassToNext();
});