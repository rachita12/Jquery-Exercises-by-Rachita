/*Following will select all the Divs with class = "module",
nad then it attaches a border to the divs.*/ 

$('div.module').css( "border", "3px solid #ff99ff" );

/*Ways in which we can select the third item in the 
#myList unordered list are :
1.) $("#myList li:nth-child(3)" )
2.) $("#myList li:eq(3)")
3.) $("#myList li").get(3)

The index-related selectors (:eq(), get())filter
the set of elements that have matched the expressions
that precede them. While (nth-child)selects all elements
that are the nth-child of their parent. 
*/

var third_elem = $('#myList li:nth-child(3)').text();
alert("The third item of list with id #myList is " + third_elem);

/*Selects the label for the search input using an attribute selector*/

$('label[for = "search"]').html("Search your name");

/*Count the number of hidden elements*/
var hidden = $('*:hidden').length;
alert("Number of hidden items are " + hidden);

/*Count the number of images with "alt" property*/
var altNum = $('img[alt]').length;
alert("Number of images with 'alt' attribute = " + altNum);

/*Select all the odd table rows*/
$('table tr:nth-child(odd)').css("backgroundColor","yellow");