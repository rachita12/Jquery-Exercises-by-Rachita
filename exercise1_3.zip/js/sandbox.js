function Selectors() {
	"use strict"
}

Selectors.prototype = {
	/*part A = Following will select all the Divs with class = "module",
	nad then it attaches a border to the divs.*/
	selectDivModule: function(){
		$('.module').addClass("divModule");
	},

	/*part B = Ways in which we can select the third item in the
	#myList unordered list are :
	1.) $("#myList li:nth-child(3)" )
	2.) $("#myList li:eq(3)")
	3.) $("#myList li").get(3)*/
	selectThirdItem: function(){
		//select 1.)
		var third_elem1 = $('#myList li:nth-child(3)');
		console.log(third_elem1);
		//select 2.)
		var third_elem2 = $("#myList li:eq(2)");
		console.log(third_elem2);
		//select 3.)
		var third_elem3 = $("#myList li").get(2);
		console.log(third_elem3);

    /*The index-related selectors (:eq(), get())filter
    the set of elements that have matched the expressions
    that precede them. While (nth-child)selects all elements
    that are the nth-child of their parent.
    */

    var third_elem = $('#myList li:nth-child(3)').text();
    alert("The best way of selecting the third element is (nth-child) and the result is " + third_elem);
	},

	/*part C = Selects the label for the search input using an attribute selector*/
	changeLabel: function() {
		$('label[for = "search"]').html("Search your name");
	},

	/*part D = Count the number of hidden elements*/
	numOfHiddenElement: function() {
		var hiddenElements = $('*:hidden').length;
		alert("Number of hidden items are " + hiddenElements);
	},

	/*part E = Count the number of images with "alt" property*/
	numOfAltImg: function(){
		var altNum = $('img[alt]').length;
		alert("Number of images with 'alt' attribute = " + altNum);
	},
	/*part F = Select all the odd table rows*/
	selectOddRows: function() {
		$('#student_data tr:nth-child(even)').addClass("oddRow");
	}
}

$(document).ready(function(){
	var selector = new Selectors();
	//part A
	selector.selectDivModule();
	//part B
	selector.selectThirdItem();
	//part C
	selector.changeLabel();
	//part D
	selector.numOfHiddenElement();
	//part E
	selector.numOfAltImg();
	//part F
	selector.selectOddRows();
});